// genre.js — danh sach the loai tinh cua alicesw (33 muc, id /lists/N.html
// lay tu nav cua site + fork goc; da kiem chung live 9 id mau tra 200).
// Moi the loai tro ve gen.js.
function execute() {
    return Response.success([
        { title: "科幻", input: "/lists/71.html", script: "gen.js" },
        { title: "校园", input: "/lists/61.html", script: "gen.js" },
        { title: "玄幻", input: "/lists/62.html", script: "gen.js" },
        { title: "乡村", input: "/lists/63.html", script: "gen.js" },
        { title: "都市", input: "/lists/64.html", script: "gen.js" },
        { title: "乱伦", input: "/lists/65.html", script: "gen.js" },
        { title: "历史", input: "/lists/67.html", script: "gen.js" },
        { title: "武侠", input: "/lists/68.html", script: "gen.js" },
        { title: "系统", input: "/lists/69.html", script: "gen.js" },
        { title: "明星", input: "/lists/72.html", script: "gen.js" },
        { title: "同人", input: "/lists/73.html", script: "gen.js" },
        { title: "强奸", input: "/lists/74.html", script: "gen.js" },
        { title: "奇幻", input: "/lists/75.html", script: "gen.js" },
        { title: "经典", input: "/lists/79.html", script: "gen.js" },
        { title: "穿越", input: "/lists/70.html", script: "gen.js" },
        { title: "凌辱", input: "/lists/46.html", script: "gen.js" },
        { title: "反差", input: "/lists/22.html", script: "gen.js" },
        { title: "堕落", input: "/lists/18.html", script: "gen.js" },
        { title: "纯爱", input: "/lists/19.html", script: "gen.js" },
        { title: "伪娘", input: "/lists/52.html", script: "gen.js" },
        { title: "萝莉", input: "/lists/48.html", script: "gen.js" },
        { title: "熟女", input: "/lists/56.html", script: "gen.js" },
        { title: "禁忌", input: "/lists/51.html", script: "gen.js" },
        { title: "NTR", input: "/lists/54.html", script: "gen.js" },
        { title: "媚黑", input: "/lists/53.html", script: "gen.js" },
        { title: "绿帽", input: "/lists/55.html", script: "gen.js" },
        { title: "调教", input: "/lists/58.html", script: "gen.js" },
        { title: "女主", input: "/lists/59.html", script: "gen.js" },
        { title: "正太", input: "/lists/50.html", script: "gen.js" },
        { title: "下克上", input: "/lists/43.html", script: "gen.js" },
        { title: "百合", input: "/lists/47.html", script: "gen.js" },
        { title: "重口", input: "/lists/21.html", script: "gen.js" },
        { title: "其他", input: "/lists/57.html", script: "gen.js" }
    ]);
}
