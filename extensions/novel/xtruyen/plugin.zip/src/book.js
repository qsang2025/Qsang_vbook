// book.js — renderer danh sach dung chung cua XTruyen.
// home.js / genre.js tro ve day voi input la duong dan chuyen muc
// (vd. /truyen/?m_orderby=latest, /theloai/tien-hiep/).
// Dong truyen theo giao dien site: .popular-item-wrap, tieu de o
// .widget-title a (hoac .popular-img a), bia o .popular-img img.
// Tuong thich Rhino ES6: chi dung var/function, noi chuoi bang +.
load('config.js');
load('safe-first.js');
load('config-helpers.js');
load('fetch-helpers.js');
load('rate-limit.js');

// Lay URL bia that: uu tien data-src (lazy-load), roi src; bo placeholder data:.
// Bia that co the nam tren CDN khac host (thumb.xtruyen.vn) nen KHONG dung
// absUrl (no viet lai host ve BASE_URL) — giu nguyen URL tuyet doi goc.
function coverOf(img) {
    if (!img) return "";
    var src = img.attr("data-src") || img.attr("src") || "";
    if (src.indexOf("data:") === 0) {
        var alt = img.attr("src") || "";
        src = (alt.indexOf("data:") === 0) ? "" : alt;
    }
    if (!src) return "";
    if (/^https?:\/\//i.test(src)) return src;
    if (src.charAt(0) === "/") return siteOrigin() + src;
    return BASE_URL + "/" + src;
}

// Mo ta dong: the loai + tac gia + chuong moi nhat, noi bang " · ".
function rowDescription(e) {
    var parts = [];
    e.select(".chapter-item a[rel='tag']").forEach(function (a) {
        var t = cleanText(a.text());
        if (t) parts.push(t);
    });
    var latest = e.select(".chapter-item a.btn-link").first();
    if (latest) {
        var lt = cleanText(latest.text());
        if (lt) parts.push(lt);
    }
    return parts.join(" · ");
}

// So trang ke ("") = het. Quet ca ?page=N va /page/N/ trong phan trang.
function nextToken(doc, page) {
    var current = parseInt(page, 10);
    if (isNaN(current) || current < 1) current = 1;
    var last = current;
    doc.select(".pagination a[href]").forEach(function (el) {
        var href = String(el.attr("href") || "");
        var m = href.match(/[?&]page=(\d+)/) || href.match(/\/page\/(\d+)\/?/);
        if (m) {
            var n = parseInt(m[1], 10);
            if (n > last) last = n;
        }
    });
    return last > current ? String(current + 1) : "";
}

function execute(query, page) {
    query = query || "";
    page = page || "1";
    var url = "";
    if (query.indexOf("http") === 0) {
        url = query;
    } else if (query.indexOf("/") === 0) {
        url = BASE_URL + query;
    } else if (query) {
        url = BASE_URL + "/?s=" + encodeURIComponent(query) + "&post_type=wp-manga";
    } else {
        url = BASE_URL + "/truyen/?m_orderby=latest";
    }
    url = pagedUrl(url, page);

    rateLimitDelay("xtruyen.vn");
    var doc = fetchDoc(url);
    if (!doc) return Response.error("Không tải được danh sách truyện: " + url + "\n\nNếu site đang bắt xác minh Cloudflare, mở trình duyệt trong app vBook vào trang này, xác minh xong rồi thử lại.");

    var items = [];
    var seen = {};
    doc.select(".popular-item-wrap").forEach(function (e) {
        var title = safeFirst(e.select(".widget-title a"));
        if (!title) title = safeFirst(e.select(".popular-img a"));
        if (!title) return;
        var link = absUrl(title.attr("href"));
        if (!link || seen[link]) return;
        var text = cleanText(title.text()) || cleanText(title.attr("title"));
        if (!text) return;
        seen[link] = true;
        var cover = e.select(".popular-img img").first();
        items.push({
            name: text,
            link: link,
            cover: coverOf(cover),
            description: rowDescription(e),
            host: siteOrigin()
        });
    });

    if (items.length === 0) return Response.error("Không đọc được danh sách truyện (site có thể đã đổi giao diện): " + url);
    return Response.success(items, nextToken(doc, page));
}
